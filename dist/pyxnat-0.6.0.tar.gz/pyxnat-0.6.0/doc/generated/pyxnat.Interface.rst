pyxnat.Interface
================

.. currentmodule:: pyxnat

.. autoclass:: Interface
