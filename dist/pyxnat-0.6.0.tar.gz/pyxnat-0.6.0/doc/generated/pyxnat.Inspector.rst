pyxnat.Inspector
================

.. currentmodule:: pyxnat

.. autoclass:: Inspector
