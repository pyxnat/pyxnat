pyxnat.SearchManager
====================

.. currentmodule:: pyxnat

.. autoclass:: SearchManager
